# Microsoft Pewrer piont paid REYL no fayk 2025 legit (TROJAN.SCREENLOCKER.WIN32)
This is the first Screenlocker i actually released so enjoy

- Heizenn

# What this Screenlocker can do

This Screenlocker has 4 functions:

1st. Overwriting Master Boot Record

2nd. Changing username

3rd. Changing password

4th. Blocking Windows key (Kinda)

# Description

This is a Quite dangerous screenlocker that overwrites master boot record setting it to 0 and is suppose to mimic a BSOD and WINRE (Windows Recovery)

# Compatibility

- Windows 11

- Windows 10

- Windows 8.1?

(I tested this malware in Windows 10 so not sure if other Windows would work but generally it would work in newer windows versions)

# For the skidders

This project will be open source for everyone to view and understand the code and use it in projects but PLEASE make sure to credit the creator (Heizenn) for what code you used. This open source project will be protected with Apache 2.0 and GPL 3.0.

# Credits

Thanks to these guys who had their code or help in this project. Thanks to them!

@AG5516 - Helped with the code

@MalwareStudio - Used MBR overwriter code

@Heizennz - Creator of the Screenlocker
