# INFO
* MD5SUM: 3abacdbddb7190c93d7f24561b201b48
* SHA256SUM: 72779e29eb9099678af9b0daa7e376322a0c8fd2c9ace68962249ed72930d9d2
* DATE: MAY 06 2022 (DOWN)

## REQUESTS HTTP:
* http://45.67.230.199/Upgrade.php  [DOWN]
* http://45.67.230.199/x64/SQLite.Interop.dll [DOWN]
* http://45.67.230.199/x86/SQLite.Interop.dll [DOWN]

## DNS REQUEST:
* ipwhois.app

## OTHER DETAILS:
Steals account credentials(electronic mail), gets info about the infected machine and 
drops some sql files. 
