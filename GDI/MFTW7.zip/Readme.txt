Start the program called MFTW7 with administrator
Enjoy :D

Made by AngryCow