 ▒█████   ███▄ ▄███▓ ██▓ ▄████▄   ██▀███   ▒█████   ███▄    █ 
▒██▒  ██▒▓██▒▀█▀ ██▒▓██▒▒██▀ ▀█  ▓██ ▒ ██▒▒██▒  ██▒ ██ ▀█   █ 
▒██░  ██▒▓██    ▓██░▒██▒▒▓█    ▄ ▓██ ░▄█ ▒▒██░  ██▒▓██  ▀█ ██▒
▒██   ██░▒██    ▒██ ░██░▒▓▓▄ ▄██▒▒██▀▀█▄  ▒██   ██░▓██▒  ▐▌██▒
░ ████▓▒░▒██▒   ░██▒░██░▒ ▓███▀ ░░██▓ ▒██▒░ ████▓▒░▒██░   ▓██░
░ ▒░▒░▒░ ░ ▒░   ░  ░░▓  ░ ░▒ ▒  ░░ ▒▓ ░▒▓░░ ▒░▒░▒░ ░ ▒░   ▒ ▒ 
  ░ ▒ ▒░ ░  ░      ░ ▒ ░  ░  ▒     ░▒ ░ ▒░  ░ ▒ ▒░ ░ ░░   ░ ▒░
░ ░ ░ ▒  ░      ░    ▒ ░░          ░░   ░ ░ ░ ░ ▒     ░   ░ ░ 
    ░ ░         ░    ░  ░ ░         ░         ░ ░           ░ 
                        ░                                    
This project is cursed. Literally.

===========================================================================

Hello guys! This is my new GDI malware. I wrote it in C# and it took me about 1 week (OF HELL) to make.
It was a week of hell because it was literally cursed. Things were breaking one after another, and
there was absolutely NO explanation for the bugs whatsoever. For example, I coded a window shrinking payload, but
instead they were expanding. I re-checked my entire code and there was absolutely no reason for the bug...

This malware can do things such as wiping user folders, C:\WINDOWS folder, program files (including x86 if exists),
swapping mouse buttons, changing text in windows to random unicode garbage and filling the boot sector with random bytes,
leaving the system unbootable.

In order to run this malware, install .NET Framework 4.0.
Windows XP/7 with basic/classic theme recommended for better performance.

This malware is public and open source.
Don't skid from it, because then you will be cursed too and your fate will be the same as mine - weird bugs.

No bugfix updates are incoming. I am tired of trying to fix this haunted project and I want to never touch it again.

Btw, if you create a file named block_omicron.txt in C:\, omicron should not even show any warnings and just
not run at all! Though, don't play with it on your host for anyway :P
You can run the script in this folder to do that.

===========================================================================

KNOWN BUGS:

- crash right before the 7th payload for different reasons
- weird payload speed on 4th payload
- i have no idea at this point everything is possible

===========================================================================

CREDITS:

- CiberBoy (bytebeat player code, critical process & bsod code)
- holymacaroniwhybruh1 (made bytebeats for 5th and 7th payloads)

===========================================================================

by silverjetes <3
04/25