﻿ ██████╗██╗██████╗ ███████╗██████╗ ██████╗  ██████╗ ██╗   ██╗███████╗██╗  ██╗███████╗
██╔════╝██║██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔═══██╗╚██╗ ██╔╝██╔════╝╚██╗██╔╝██╔════╝
██║     ██║██████╔╝█████╗  ██████╔╝██████╔╝██║   ██║ ╚████╔╝ █████╗   ╚███╔╝ █████╗  
██║     ██║██╔══██╗██╔══╝  ██╔══██╗██╔══██╗██║   ██║  ╚██╔╝  ██╔══╝   ██╔██╗ ██╔══╝  
╚██████╗██║██████╔╝███████╗██║  ██║██████╔╝╚██████╔╝   ██║██╗███████╗██╔╝ ██╗███████╗
 ╚═════╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝    ╚═╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
Peta Bonus

===============================================================================================================

Hello everyone! This is my new trojan named CiberBoy.exe. It's a Monoxide remake.
I wrote it in C# and it took me about 2 weeks to make.

This malware is not private, means it's free to download!
Please make sure to run it only in a virtual machine, and don't use it for malicious purposes!

In order to run, install .NET Framework 4.0. I did not include it in this archive as since I don't want
my archive to be very big. Windows XP/7 with Basic theme recommended for fast GDI performance.

This malware has randomized payloads, random file deletion, file opening, cool bytebeats, and more!
Though, tested, that it might crash on versions higher than XP. It will be patched later, but for now, run it on XP only.

==========================================================================================================

CREDITS:
MalwareLab150 (aka 2.0, Mattia) for MBR and sine waves
CiberBoy for helping me a lot
Inspired by Monoxide.exe from WiPet.
Shoutout to masteralbert100 for giving me some bytebeats (they weren't included because of some issuse :<)

==========================================================================================================

by silverjetes <3
02/25