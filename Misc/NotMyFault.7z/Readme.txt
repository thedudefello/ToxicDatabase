NotMyFault v4.21

You can use the GUI versions or the command-line version. NotMyFault requires administrative privileges and comes
in three flavors: 32-bit, 64-bit and 64-bit ARM. Each flavor has a command-line equivalent that has a "c" in its name.

Command-line examples:
notmyfaultc.exe crash crash_type_num

	crash type:
		0x01: High IRQL fault (Kernel-mode)
		0x02: Buffer overflow
		0x03: Code overwrite
		0x04: Stack trash
		0x05: High IRQL fault (User-mode)
		0x06: Stack overflow
		0x07: Hardcoded breakpoint
		0x08: Double Free

notmyfaultc.exe hang hang_type_num

	hang type:
		0x01: Hang with IRP
		0x02: Hang with DPC