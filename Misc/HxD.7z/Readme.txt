HxD Hex Editor 2.5.0.0 (11.02.2021)

I have included my version of the HxD icon, which is fully transparent. You can replace the ugly opaque icon
after installing HxD using Resource Hacker. Sometimes Windows takes a while to refresh icon cache, so don't worry
if changes don't become apparent immediately.

Thank you for downloading from Enderman!
https://enderman.ch