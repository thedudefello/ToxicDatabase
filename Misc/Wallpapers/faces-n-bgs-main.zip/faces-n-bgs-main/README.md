# faces-n-bgs
Faces and Backgrounds

This is where I put all my backgrounds and icons here.

You can use those images without credit for your malwares, wallpapers, and other creations.
