Hello

Virus created by riderfly

password : missclick?

NOTE : not try on ur real pc or its ded (the virus totaly destroy explorer.exe)