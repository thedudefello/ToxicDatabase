NOSKID!
By Windows 11 GDI and Tom 
