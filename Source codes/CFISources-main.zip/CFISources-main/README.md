# CFISources
My Sources from used malwares

You can ask the AI to convert it to another Programming Languages
