Bootloader in assembly con effetti gdi . Se li riutilizzate taggatemi su YouTube @MalwareLab150
