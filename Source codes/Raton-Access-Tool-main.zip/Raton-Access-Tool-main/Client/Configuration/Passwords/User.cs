﻿namespace Client.Configuration.Passwords
{
    class Account
    {
        public string URL { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
