﻿using System;

namespace Client.Things
{
    internal class Config
    {
        public static string MutexString = "silly1";
        public static string Host = "127.0.0.1"; // Cambiado a 127.0.0.1
        public static int Port = 8080; // Cambiado a 8080
        public static bool Startup = false; // Cambiado a false
        public static int Delay = 0; // Cambiado a 0
        public static bool ProcessCritical = false; // Cambiado a false
        public static bool HideFile = false; // Cambiado a false
        public static bool Box = false; // Cambiado a false
        public static string BoxMsg = "silly9";
        public static string BoxIcon = "silly10";
        public static bool UAC = false; // Cambiado a false
        public static bool Assist = false; // Cambiado a false
        public static bool OpenWebsite = false; // Cambiado a false
        public static string Website = "silly14";
        public static bool VM = false; // Cambiado a false
        public static string Tag = "silly16";
        public static string BoxTit = "silly17";
        public static bool HidProc = false; // Cambiado a false
        public static bool UACBy = false; // Mantener en true
    }
}
