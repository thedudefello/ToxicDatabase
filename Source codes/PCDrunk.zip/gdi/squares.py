import sys
import random

from win32con import PATINVERT
from win32gui import GetDC, PatBlt


def draw_rects(dc, x, y, w, h, count, dx, dy):
    for i in range(count):
        PatBlt(dc, x + i * dx, y + i * dy, w - 2 * i * dx, h - 2 * i * dy, PATINVERT)


def main(*argv):
    dc = GetDC(0)
    draw_rects(dc, random.randint(0,10000), random.randint(0,1000), random.randint(0,250), random.randint(0,250), random.randint(0,100), random.randint(0,10), random.randint(0,10))


if __name__ == "__main__":
    rc = main(*sys.argv[1:])

