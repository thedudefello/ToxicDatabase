﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Crypto;
using RoverLock.UI;
using RoverLock.Win;

namespace RoverLock
{
    public partial class MainWindow : Window
    {
        public static ListBox listbox { get; set; }
        public static double percent { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            listbox = select_box;
        }
        private void btn_clear_Click(object sender, RoutedEventArgs e)
        {
            if (percent > 0)
                return;
            listbox.Items.Clear();
        }
        private async void btn_process_Click(object sender, RoutedEventArgs e)
        {
            Error_Win error = new Error_Win();
            if (percent > 0)
                return;
            if (kokot.Pass_box.Length < 16)
            {
                error.diag = "Password cannot be less than 16 characters";
                error.ShowDialog();
                return;
            }
            if(listbox.Items.IsEmpty)
            {
                error.diag = "You need to select some files before executing";
                error.ShowDialog();
                return;
            }
            if(radials.radial_btn.IsChecked == false && radials.radial_btn2.IsChecked == false)
            {
                error.diag = "Please select mode within you want to work";
                error.ShowDialog();
                return;
            }
            ItemCollection files = listbox.Items;
            double count = 0.0;
            string key = kokot.Pass_box;
            radials.radial_btn.IsEnabled = false;
            radials.radial_btn2.IsEnabled = false;
            loading_circle.Visibility = Visibility.Visible;
            foreach (string file in files)
            {
                show_lbl.Content = file;
                if (radials.radial_btn.IsChecked == true)
                {
                    await Task.Run(() => {
                        aes.EncryptFile(file, key);
                    });
                }
                else if (radials.radial_btn2.IsChecked == true)
                {
                    await Task.Run(() =>
                    {
                        aes.DecryptFile(file, key);
                    });
                }
                percent = (double)((count += 1.0) / files.Count * 386);
                sub_bar.Width = percent;
                status_lbl.Content = (Convert.ToInt32(percent / 3.86)).ToString() + " %";
            }
            loading_circle.Visibility = Visibility.Hidden;
            count = 0;
            percent = 0;
            sub_bar.Width = 0;
            show_lbl.Content = "";
            status_lbl.Content = "";
            radials.radial_btn.IsEnabled = true;
            radials.radial_btn2.IsEnabled = true;
        }
        private void lbl_exit_MouseMove(object sender, MouseEventArgs e)
        {
            lbl_exit.Background = new SolidColorBrush(Colors.Gray);
        }
        private void lbl_exit_MouseLeave(object sender, MouseEventArgs e)
        {
            lbl_exit.Background = new SolidColorBrush(Colors.Black);
        }
        private void lbl_exit_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (percent > 0)
                return;
            Environment.Exit(-1);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }
        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            
        }
    }
}
