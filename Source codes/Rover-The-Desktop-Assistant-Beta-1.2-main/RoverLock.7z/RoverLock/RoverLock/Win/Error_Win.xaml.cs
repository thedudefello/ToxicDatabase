﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RoverLock.Win
{
    /// <summary>
    /// Interaction logic for Error_Win.xaml
    /// </summary>
    public partial class Error_Win : Window
    {
        public Error_Win()
        {
            InitializeComponent();
        }
        public string diag
        {
            get { return error_dialog.Text; }
            set { error_dialog.Text = value; }
        }
        private void exit_lbl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Hide();
            Close();
        }
        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }
        private void exit_lbl_MouseLeave(object sender, MouseEventArgs e)
        {
            exit_lbl.Background = new SolidColorBrush(Colors.Black);
        }
        private void exit_lbl_MouseMove(object sender, MouseEventArgs e)
        {
            exit_lbl.Background = new SolidColorBrush(Colors.Gray);
        }
    }
}
