﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoverLock
{
    /// <summary>
    /// Interaction logic for file_bar.xaml
    /// </summary>
    public partial class file_bar : UserControl
    {
        public file_bar()
        {
            InitializeComponent();
        }
        private void btn_file_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            open_file();
        }
        private void box_file_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(box_file.Text) && !string.IsNullOrWhiteSpace(box_file.Text))
                btn_file.Content = "Add";
            else
                btn_file.Content = "Browse";
        }
        private void box_file_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                open_file();
        }
        bool error = false;
        private void open_file()
        {
            if (MainWindow.percent > 0)
                return;
            try
            {
                if (!string.IsNullOrEmpty(box_file.Text) && !string.IsNullOrWhiteSpace(box_file.Text))
                {
                    MainWindow.listbox.Items.Add(box_file.Text);
                    return;
                }
                OpenFileDialog browser = new OpenFileDialog();
                browser.Multiselect = true;
                if (browser.ShowDialog() == true)
                {
                    foreach (string file in browser.FileNames)
                    {
                        MainWindow.listbox.Items.Add(file);
                    }
                }
            }
            catch 
            {
                error = true;
            }
            finally
            {
                if (error)
                    MessageBox.Show("Some files couldn't be loaded", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                error = false;
            }
        }
    }
}
