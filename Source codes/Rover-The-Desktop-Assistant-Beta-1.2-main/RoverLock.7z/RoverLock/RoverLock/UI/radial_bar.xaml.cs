﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoverLock.UI
{
    /// <summary>
    /// Interaction logic for radial_bar.xaml
    /// </summary>
    public partial class radial_bar : UserControl
    {
        public radial_bar()
        {
            InitializeComponent();
        }
        private void radial_btn_Click(object sender, RoutedEventArgs e)
        {
            radial_btn2.IsChecked = false;
        }
        private void radial_btn2_Click(object sender, RoutedEventArgs e)
        {
            radial_btn.IsChecked = false;
        }
    }
}
