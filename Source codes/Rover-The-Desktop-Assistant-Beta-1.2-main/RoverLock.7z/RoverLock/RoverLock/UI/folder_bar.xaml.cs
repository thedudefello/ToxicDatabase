﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoverLock.UI
{
    /// <summary>
    /// Interaction logic for folder_bar.xaml
    /// </summary>
    public partial class folder_bar : UserControl
    {
        public folder_bar()
        {
            InitializeComponent();
        }
        private void btn_folder_Click(object sender, RoutedEventArgs e)
        {
            open_box();
        }
        bool error = false;
        private void open_box()
        {
            if (MainWindow.percent > 0)
                return;
            try
            {
                if (!string.IsNullOrEmpty(box_folder.Text) && !string.IsNullOrWhiteSpace(box_folder.Text))
                {
                    DirectoryInfo dir_info = new DirectoryInfo(box_folder.Text);
                    FileInfo[] files = dir_info.GetFiles();
                    foreach (FileInfo file in files)
                    {
                        MainWindow.listbox.Items.Add(file.FullName);
                    }
                    return;
                }
                using (System.Windows.Forms.FolderBrowserDialog dir_browser =
                    new System.Windows.Forms.FolderBrowserDialog())
                {
                    if (dir_browser.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        DirectoryInfo dir_info = new DirectoryInfo(dir_browser.SelectedPath);
                        FileInfo[] files = dir_info.GetFiles();
                        foreach (FileInfo file in files)
                        {
                            MainWindow.listbox.Items.Add(file.FullName);
                        }
                        DirectoryInfo[] dirs = dir_info.GetDirectories("*", SearchOption.AllDirectories);
                        foreach (DirectoryInfo dir in dirs)
                        {
                            FileInfo[] file = dir.GetFiles();
                            foreach (FileInfo sfile in file)
                            {
                                MainWindow.listbox.Items.Add(sfile.FullName);
                            }
                        }
                    }
                }
            }
            catch
            {
                error = true;
            }
            finally
            {
                if (error)
                    MessageBox.Show("Some files couldn't be loaded", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                error = false;
            }
        }
        private void box_folder_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                open_box();
        }
        private void box_folder_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(box_folder.Text) || string.IsNullOrWhiteSpace(box_folder.Text))
                btn_folder.Content = "Browse";
            else
                btn_folder.Content = "Add";
        }
    }
}
