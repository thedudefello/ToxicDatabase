﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoverLock.UI
{
    /// <summary>
    /// Interaction logic for pass_bar.xaml
    /// </summary>
    public partial class pass_bar : UserControl
    {
        public pass_bar()
        {
            InitializeComponent();
        }
        public string Pass_box 
        {
            get { return box_pass.Text; } 
            set { box_pass.Text = value; }
        }
        private void btn_clear_Click(object sender, RoutedEventArgs e)
        {
            box_pass.Clear();
            box_pass.Focus();
        }
    }
}
