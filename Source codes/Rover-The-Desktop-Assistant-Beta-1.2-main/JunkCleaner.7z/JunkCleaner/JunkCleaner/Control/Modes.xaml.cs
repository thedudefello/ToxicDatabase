﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JunkCleaner.Control
{
    /// <summary>
    /// Interaction logic for Modes.xaml
    /// </summary>
    public partial class Modes : UserControl
    {
        public bool r_quick
        {
            get { return radial_quick.IsChecked.GetValueOrDefault(); }
        }
        public bool r_deep
        {
            get { return radial_deep.IsChecked.GetValueOrDefault(); }
        }
        public Modes()
        {
            InitializeComponent();
        }
        private void radial_quick_Click(object sender, RoutedEventArgs e)
        {
            radial_deep.IsChecked = false;
        }
        private void radial_deep_Click(object sender, RoutedEventArgs e)
        {
            radial_quick.IsChecked = false;
        }
    }
}
