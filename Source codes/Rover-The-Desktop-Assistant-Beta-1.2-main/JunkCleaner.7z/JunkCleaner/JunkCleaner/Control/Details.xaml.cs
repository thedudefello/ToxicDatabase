﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JunkCleaner.Control
{
    /// <summary>
    /// Interaction logic for Details.xaml
    /// </summary>
    public partial class Details : UserControl
    {
        public Details()
        {
            InitializeComponent();
        }
        public string drive
        {
            get { return lbl_drive.Content.ToString(); }
            set { lbl_drive.Content = value; }
        }
        public string drive_size
        {
            get { return lbl_drive_size.Content.ToString(); }
            set { lbl_drive_size.Content = value; }
        }
        public string drive_free
        {
            get { return lbl_drive_free.Content.ToString(); }
            set { lbl_drive_free.Content = value; }
        }
        public string junk
        {
            get { return lbl_junk_files.Content.ToString(); }
            set { lbl_junk_files.Content = value; }
        }
        public string released
        {
            get { return lbl_released.Content.ToString(); }
            set { lbl_released.Content = value; }
        }
    }
}
