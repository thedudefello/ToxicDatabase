﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JunkCleaner.Control
{
    /// <summary>
    /// Interaction logic for Button.xaml
    /// </summary>
    public partial class Button : UserControl, INotifyPropertyChanged
    {
        public Button()
        {
            DataContext = this;
            InitializeComponent();
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private string btn_text;
        private Brush custom_brush;
        public Brush Custom_brush
        {
            get { return  custom_brush; }
            set 
            { 
                custom_brush  = value;
                OnPropertyChanged();
            }
        }
        private void OnPropertyChanged([CallerMemberName] string propertyname = null)
        {
            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        public string Btn_text
        {
            get { return btn_text; }
            set 
            { 
                btn_text = value;
                lbl_button.Content = btn_text;
            }
        }
        private int font_size;

        public int Font_size
        {
            get { return font_size; }
            set 
            { 
                font_size = value;
                lbl_button.FontSize = font_size;
            }
        }
    }
}
