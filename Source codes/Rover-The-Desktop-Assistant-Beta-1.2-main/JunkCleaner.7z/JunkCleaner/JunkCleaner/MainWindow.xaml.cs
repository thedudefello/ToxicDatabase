﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using JunkCleaner.Wpf;
using form = System.Windows.Forms;
using JunkCleaner.Control;
using System.IO;
using Microsoft.Win32;
using System.Security.Permissions;
using System.Threading;

namespace JunkCleaner
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private LinearGradientBrush yellow_brush = (LinearGradientBrush)Application.Current.Resources["Yellow_Brush"];
        private LinearGradientBrush red_brush = (LinearGradientBrush)Application.Current.Resources["Red_Brush"];
        public static string selected_disk;
        private string[] fast_scan = { @"C:\Users\Clutter\Desktop\Temp", Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
        + @"\AppData\Local\Temp"};
        public string processing
        {
            get { return lbl_file.Content.ToString(); }
            set { lbl_file.Content = value; }
        }
        public MainWindow()
        {
            InitializeComponent();
        }
        private void exit_lbl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Environment.Exit(-1);
        }
        private void border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                this.DragMove();
        }
        private void btn_option_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (File_Process.is_running)
                return;
            Option_Win option_win = new Option_Win(this);
            option_win.ShowDialog();
        }
        private void Exit_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Environment.Exit(-1);
        }
        public void Driver(string name)
        {
            selected_disk = name;
            DriveInfo sel_drive = new DriveInfo(name);
            details.drive = " Selected Drive: " + name;
            details.drive_size = " Drive Size: " + (Math.Round(sel_drive.TotalSize / Math.Pow(1024, 3), 2)) + " GB";
            details.drive_free = " Drive Available Space: " + (Math.Round(sel_drive.AvailableFreeSpace / Math.Pow(1024, 3), 2)) +  " GB";
        }
        private void btn_option_MouseLeave(object sender, MouseEventArgs e)
        {
            btn_option.Background = new SolidColorBrush(Colors.Black);
        }
        private void btn_option_MouseMove(object sender, MouseEventArgs e)
        {
           btn_option.Background = new SolidColorBrush(Colors.Gray);
        }
        private void Button_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (File_Process.is_running)
                return;
            if (!Option_Win.selected_radial)
                Driver(@"C:\");
            if (modes.radial_quick.IsChecked == true)
            {
                if (selected_disk != @"C:\")
                {
                    Error_Win error = new Error_Win(this);
                    error.Error_Dialog("Quick Scan is not available for disk!" + selected_disk, red_brush, 0);
                    error.ShowDialog();
                    return;
                }
                File_Process junky = new File_Process(this);
                junky.Junking(fast_scan);
            }
            else if (modes.radial_deep.IsChecked == true)
            {
                File_Process junky = new File_Process(this);
                junky.Junking(selected_disk);
            }
            else
            {
                Error_Win error = new Error_Win(this);
                error.Error_Dialog("You must select one of the available modes" + Environment.NewLine +
                    "before the action!", red_brush, 0);
                error.ShowDialog();
            }
        }
        private void btn_stop(object sender, MouseButtonEventArgs e)
        {
            if (!File_Process.is_running)
                return;
            File_Process.is_running = false;
            Error_Win error = new Error_Win(this);
            error.Error_Dialog("Are you sure you want to cancel the scan?" + Environment.NewLine +
                "If you cancel this operation, all the junk files will not be deleted!", yellow_brush, 35);
            error.ShowDialog();
            if (error.output)
                File_Process.is_breakable = true;
            File_Process.is_running = true;
            error.Close();
        }
        private void btn_clear_MouseDown(object sender, MouseButtonEventArgs e)
        {
            list_items.Items.Clear();
        }
        private void btn_copy_MouseDown(object sender, MouseButtonEventArgs e)
        {
            list_settext(false);
        }
        private void Button_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            list_settext(true);
        }
        private void list_settext(bool set)
        {
            switch (set)
            {
                case true:
                    string store = "";
                    foreach (string item in list_items.Items)
                        store = store + item + Environment.NewLine;
                    SaveFileDialog save = new SaveFileDialog();
                    save.DefaultExt = "txt";
                    save.Filter = "Text Files (*.txt)|*.txt|All Files(*.*)|*.*";
                    if (save.ShowDialog() == true)
                        File.WriteAllText(save.FileName, store);
                    break;
                case false:
                    string copy = "";
                    foreach (string item in list_items.Items)
                        copy = copy + item + Environment.NewLine;
                    Clipboard.SetText(copy);
                    break;
            }
        }
        public void Dialog_Vars(int junk_count, double size)
        {
            Dispatcher.Invoke(() => 
            {
                double rounded = Math.Round(size, 2);
                details.junk = "Junk Files: " + junk_count.ToString();
                details.released = "Released: " + rounded + " MB";
            });
        }
    }
}
