﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace JunkCleaner.Wpf
{
    /// <summary>
    /// Interaction logic for Option_Win.xaml
    /// </summary>
    public partial class Option_Win : Window
    {
        private MainWindow main;
        public static bool selected_radial = false;
        public Option_Win(MainWindow maininstance)
        {
            InitializeComponent();
            main = maininstance;
            Owner = maininstance;
            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach (DriveInfo drive in drives)
                list_drive.Items.Add(drive.Name);
        }
        private void Exit_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Hide();
            this.Close();
        }
        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }
        private void open_box()
        {
            try
            {
                selected_radial = true;
                main.Driver(list_drive.SelectedItem.ToString());
            }
            catch 
            {
                selected_radial = false;
                main.Driver(list_drive.Items[0].ToString());
            }
            Hide();
            Close();
        }
        private void Button_MouseDown(object sender, MouseButtonEventArgs e)
        {
            open_box();
        }
        private void list_drive_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
                open_box();
        }
    }
}
