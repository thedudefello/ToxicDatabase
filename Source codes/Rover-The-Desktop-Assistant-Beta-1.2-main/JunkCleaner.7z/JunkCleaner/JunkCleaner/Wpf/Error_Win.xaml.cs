﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JunkCleaner.Wpf
{
    /// <summary>
    /// Interaction logic for Error_Win.xaml
    /// </summary>
    public partial class Error_Win : Window
    {
        public Error_Win(MainWindow maininstance)
        {
            InitializeComponent();
            Owner = maininstance;
        }
        public bool output;
        public void Error_Dialog(string s, LinearGradientBrush brush, int h)
        {
            GridLength length = new GridLength(h, GridUnitType.Pixel);
            Row3.Height = length;
            lbl_error.Text = s;
            border.BorderBrush = brush;
        }
        private void Exit_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Hide();
            Close();
        }
        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }
        private void btn_no(object sender, MouseButtonEventArgs e)
        {
            output = false;
            Hide();
        }
        private void btn_yes(object sender, MouseButtonEventArgs e)
        {
            output = true;
            Hide();
        }
    }
}
