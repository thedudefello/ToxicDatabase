﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace JunkCleaner
{
    public class File_Process
    {
        private MainWindow main;
        private static int file_count = 0;
        private static double file_size = 0;
        public static bool is_breakable = false;
        public static bool is_running = false;
        private static List<string> stored_files = new List<string>();
        public File_Process(MainWindow maininstance)
        {
            main = maininstance;
        }
        public async void Junking(string[] main_array)
        {
            is_running = true;
            is_breakable = false;
            main.loading_circle.Visibility = System.Windows.Visibility.Visible;
            try
            {
                await Task.Run(() =>
                {
                    Clear_Dialog();
                    foreach (string rootDirectory in main_array)
                    {
                        IEnumerable<string> allDirectories = GetAllDirectories(rootDirectory);
                        foreach (string directoryPath in allDirectories)
                            process_files(directoryPath);
                    }
                    Delete();
                });
            }
            catch { }
            main.loading_circle.Visibility = System.Windows.Visibility.Hidden;
            main.processing = "";
            main.status.Content = "";
            main.progress_bar.Width = 0;
            is_running = false;
        }
        public async void Junking(string rootDirectory)
        {
            is_running = true;
            is_breakable = false;
            main.loading_circle.Visibility = System.Windows.Visibility.Visible;
            try
            {
                await Task.Run(() =>
                {
                    Clear_Dialog();
                    IEnumerable<string> allDirectories = GetAllDirectories(rootDirectory);
                    foreach (string directoryPath in allDirectories)
                        process_files(directoryPath, "*.log");
                    Delete();
                });
            }
            catch { }
            main.loading_circle.Visibility = System.Windows.Visibility.Hidden;
            main.processing = "";
            main.status.Content = "";
            main.progress_bar.Width = 0;
            is_running = false;
        }
        static IEnumerable<string> GetAllDirectories(string directory)
        {
            List<string> directories = new List<string>();
            directories.Add(directory);
            try
            {
                string[] subDirectories = Directory.GetDirectories(directory);
                foreach (string subDirectory in subDirectories)
                    directories.AddRange(GetAllDirectories(subDirectory));
            }
            catch { }
            return directories;
        }
        public void process_files(string directory)
        {
            try
            {
                IEnumerable<string> files = Directory.EnumerateFiles(directory);
                foreach (string file in files)
                {
                    if (is_breakable)
                        break;
                    Freeze();
                    FileInfo file_info = new FileInfo(file);
                    if (!IsFileInUse(file))
                    {
                        main.Dispatcher.Invoke(() =>
                        {
                            double size_mb = Math.Round(file_info.Length / Math.Pow(1024, 2), 2);
                            file_size += size_mb;
                            stored_files.Add(file);
                            main.list_items.Items.Add(file);
                            main.processing = file;
                            main.Dialog_Vars(file_count += 1, file_size);
                        });
                    }
                }
            }
            catch { }
        }
        public void process_files(string directory, string searchpattern)
        {
            try
            {
                IEnumerable<string> files = Directory.EnumerateFiles(directory, searchpattern);
                foreach (string file in files)
                {
                    if (is_breakable)
                        break;
                    Freeze();
                    FileInfo file_info = new FileInfo(file);
                    if (!IsFileInUse(file))
                    {
                        main.Dispatcher.Invoke(() =>
                        {
                            double size_mb = Math.Round(file_info.Length / Math.Pow(1024, 2), 2);
                            file_size += size_mb;
                            stored_files.Add(file);
                            main.list_items.Items.Add(file);
                            main.processing = file;
                            main.Dialog_Vars(file_count += 1, file_size);
                        });
                    }
                }
            }
            catch { }
        }
        private void Delete()
        {
            int count = 0;
            foreach (string file in stored_files)
            {
                if (is_breakable)
                    break;
                Freeze();
                count += 1;
                double current_percent = (double)count / stored_files.Count * 100;
                double bar_percent = (double)count / stored_files.Count * 268;
                File.Delete(file);
                main.Dispatcher.Invoke(() =>
                {
                    main.status.Content = Math.Round(current_percent, 0) + " %";
                    main.progress_bar.Width = bar_percent;
                });
                Thread.Sleep(1);
            }
        }
        static bool IsFileInUse(string filePath)
        {
            try
            {
                using (FileStream stream = File.Open(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                    return false;
            }
            catch (IOException)
            {
                return true;
            }
        }
        private void Clear_Dialog()
        {
            main.Dispatcher.Invoke(() => 
            {
                file_count = 0;
                file_size = 0;
                main.Dialog_Vars(0, 0);
                main.list_items.Items.Clear();
                if(stored_files != null)
                    stored_files.Clear();
            });
        }
        private static void Freeze()
        {
            while (!is_running)
                Thread.Sleep(10);
        }
    }
}
