﻿// Decompiled with JetBrains decompiler
// Type: GDISOLA.Program
// Assembly: Project4, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9AD7046F-FC19-49B8-B90B-AB83857CA6C9
// Assembly location: F:\Malware\Nikosoft Skidded Shit\Project4.exe

using System;
using System.Runtime.InteropServices;
using System.Threading;

#nullable disable
namespace GDISOLA
{
  internal class Program
  {
    private const int SRCCOPY = 13369376;
    private const int SM_CXSCREEN = 0;
    private const int SM_CYSCREEN = 1;

    [DllImport("user32.dll")]
    private static extern IntPtr GetDesktopWindow();

    [DllImport("user32.dll")]
    private static extern IntPtr GetDC(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateCompatibleDC(IntPtr hdc);

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);

    [DllImport("gdi32.dll")]
    private static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr hObject);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteDC(IntPtr hdc);

    [DllImport("gdi32.dll")]
    private static extern bool BitBlt(
      IntPtr hdcDest,
      int nXDest,
      int nYDest,
      int nWidth,
      int nHeight,
      IntPtr hdcSrc,
      int nXSrc,
      int nYSrc,
      uint dwRop);

    [DllImport("gdi32.dll")]
    private static extern bool SetDIBitsToDevice(
      IntPtr hdc,
      int xDest,
      int yDest,
      int width,
      int height,
      int xSrc,
      int ySrc,
      uint startScan,
      uint cLines,
      byte[] lpBits,
      ref Program.BITMAPINFO lpBitsInfo,
      uint iUsage);

    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);

    private static void Main()
    {
      Program.SetProcessDPIAware();
      Program.HslShader(Program.GetSystemMetrics(0), Program.GetSystemMetrics(1));
    }

    private static void HslShader(int width, int height)
    {
      IntPtr desktopWindow = Program.GetDesktopWindow();
      IntPtr dc = Program.GetDC(desktopWindow);
      byte[] numArray = new byte[width * height * 3];
      Program.BITMAPINFO lpBitsInfo = new Program.BITMAPINFO()
      {
        bmiHeader = new Program.BITMAPINFOHEADER()
        {
          biSize = (uint) Marshal.SizeOf(typeof (Program.BITMAPINFOHEADER)),
          biWidth = width,
          biHeight = -height,
          biPlanes = 1,
          biBitCount = 24,
          biCompression = 0
        },
        bmiColors = new Program.RGBQUAD[1]
      };
      int offset = 0;
      int num = 20000;
      int tickCount = Environment.TickCount;
      while (Environment.TickCount - tickCount < num)
      {
        Program.GenerateHslEffect(numArray, width, height, offset);
        Program.SetDIBitsToDevice(dc, 0, 0, width, height, 0, 0, 0U, (uint) height, numArray, ref lpBitsInfo, 0U);
        offset += 10;
        Thread.Sleep(0);
      }
      Program.ReleaseDC(desktopWindow, dc);
    }

    private static void GenerateHslEffect(byte[] pixelData, int width, int height, int offset)
    {
      for (int index1 = 0; index1 < height; ++index1)
      {
        for (int index2 = 0; index2 < width; ++index2)
        {
          byte r;
          byte g;
          byte b;
          Program.ColorHsl(((int) ((double) index1 + (double) index1 * Math.Sin((double) index2 / 16.0) + (double) index1 + (double) index1 * Math.Sin((double) index1 / 8.0) + (double) index1 + (double) index1 * Math.Sin((double) (index2 + index1) / 16.0) + (double) index1 + (double) index1 * Math.Sin(Math.Sqrt((double) (index2 * index2 + index1 * index1)) / 8.0)) / 4 + offset) % 360, out r, out g, out b);
          int index3 = (index1 * width + index2) * 3;
          pixelData[index3] = b;
          pixelData[index3 + 1] = g;
          pixelData[index3 + 2] = r;
        }
      }
    }

    private static void ColorHsl(int length, out byte r, out byte g, out byte b)
    {
      double num1 = (double) (length % 360);
      double num2 = 1.0;
      double num3 = 0.5;
      double num4 = (1.0 - Math.Abs(2.0 * num3 - 1.0)) * num2;
      double num5 = num4 * (1.0 - Math.Abs(num1 / 60.0 % 2.0 - 1.0));
      double num6 = num3 - num4 / 2.0;
      double num7;
      double num8;
      double num9;
      if (num1 < 60.0)
      {
        num7 = num4;
        num8 = num5;
        num9 = 0.0;
      }
      else if (num1 < 120.0)
      {
        num7 = num5;
        num8 = num4;
        num9 = 0.0;
      }
      else if (num1 < 180.0)
      {
        num7 = 0.0;
        num8 = num4;
        num9 = num5;
      }
      else if (num1 < 240.0)
      {
        num7 = 0.0;
        num8 = num5;
        num9 = num4;
      }
      else if (num1 < 300.0)
      {
        num7 = num5;
        num8 = 0.0;
        num9 = num4;
      }
      else
      {
        num7 = num4;
        num8 = 0.0;
        num9 = num5;
      }
      r = (byte) ((num7 + num6) * (double) byte.MaxValue);
      g = (byte) ((num8 + num6) * (double) byte.MaxValue);
      b = (byte) ((num9 + num6) * (double) byte.MaxValue);
    }

    public struct BITMAPINFOHEADER
    {
      public uint biSize;
      public int biWidth;
      public int biHeight;
      public ushort biPlanes;
      public ushort biBitCount;
      public uint biCompression;
      public uint biSizeImage;
      public int biXPelsPerMeter;
      public int biYPelsPerMeter;
      public uint biClrUsed;
      public uint biClrImportant;
    }

    public struct RGBQUAD
    {
      public byte rgbBlue;
      public byte rgbGreen;
      public byte rgbRed;
      public byte rgbReserved;
    }

    public struct BITMAPINFO
    {
      public Program.BITMAPINFOHEADER bmiHeader;
      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
      public Program.RGBQUAD[] bmiColors;
    }
  }
}
