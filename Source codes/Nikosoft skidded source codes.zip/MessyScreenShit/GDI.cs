﻿// Decompiled with JetBrains decompiler
// Type: GDI
// Assembly: Project4, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 913ACCAD-CB5F-4564-8E33-4458997281CA
// Assembly location: F:\Malware\Nikosoft Skidded Shit\MessyScreen.exe

using System;
using System.Runtime.InteropServices;
using System.Threading;

#nullable disable
public class GDI
{
  public const uint DSTINVERT = 5570569;
  public const int SM_CXSCREEN = 0;
  public const int SM_CYSCREEN = 1;

  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool PatBlt(IntPtr hdc, int x, int y, int width, int height, uint rop);

  [DllImport("user32.dll")]
  public static extern IntPtr GetDC(IntPtr hWnd);

  [DllImport("user32.dll")]
  public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

  [DllImport("user32.dll")]
  public static extern int GetSystemMetrics(int nIndex);

  public static void Main(string[] args)
  {
    IntPtr dc = GDI.GetDC(IntPtr.Zero);
    if (dc == IntPtr.Zero)
    {
      Console.WriteLine("Failed to get device context.");
    }
    else
    {
      int systemMetrics1 = GDI.GetSystemMetrics(0);
      int systemMetrics2 = GDI.GetSystemMetrics(1);
      Random random = new Random();
      for (int index = 0; index < 100; ++index)
      {
        int x = random.Next(0, systemMetrics1);
        int y = random.Next(0, systemMetrics2);
        int width = random.Next(50, 200);
        int height = random.Next(50, 200);
        GDI.PatBlt(dc, x, y, width, height, 5570569U);
        Thread.Sleep(100);
      }
      GDI.ReleaseDC(IntPtr.Zero, dc);
    }
  }
}
