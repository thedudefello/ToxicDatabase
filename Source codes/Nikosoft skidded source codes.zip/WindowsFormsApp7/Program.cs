﻿// Decompiled with JetBrains decompiler
// Type: WindowsFormsApp7.Program
// Assembly: WindowsFormsApp7, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E908FC6C-F87D-440C-92BE-3E4D533491DF
// Assembly location: F:\Malware\Nikosoft Skidded Shit\WindowsFormsApp7.exe

using System;
using System.Windows.Forms;

#nullable disable
namespace WindowsFormsApp7
{
  internal static class Program
  {
    [STAThread]
    private static void Main()
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run((Form) new Form1());
    }
  }
}
