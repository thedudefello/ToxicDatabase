﻿// Decompiled with JetBrains decompiler
// Type: WindowsFormsApp7.Properties.Settings
// Assembly: WindowsFormsApp7, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E908FC6C-F87D-440C-92BE-3E4D533491DF
// Assembly location: F:\Malware\Nikosoft Skidded Shit\WindowsFormsApp7.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

#nullable disable
namespace WindowsFormsApp7.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default => Settings.defaultInstance;
  }
}
