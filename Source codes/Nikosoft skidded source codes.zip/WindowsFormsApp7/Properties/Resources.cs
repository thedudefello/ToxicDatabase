﻿// Decompiled with JetBrains decompiler
// Type: WindowsFormsApp7.Properties.Resources
// Assembly: WindowsFormsApp7, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E908FC6C-F87D-440C-92BE-3E4D533491DF
// Assembly location: F:\Malware\Nikosoft Skidded Shit\WindowsFormsApp7.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace WindowsFormsApp7.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (WindowsFormsApp7.Properties.Resources.resourceMan == null)
          WindowsFormsApp7.Properties.Resources.resourceMan = new ResourceManager("WindowsFormsApp7.Properties.Resources", typeof (WindowsFormsApp7.Properties.Resources).Assembly);
        return WindowsFormsApp7.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => WindowsFormsApp7.Properties.Resources.resourceCulture;
      set => WindowsFormsApp7.Properties.Resources.resourceCulture = value;
    }
  }
}
