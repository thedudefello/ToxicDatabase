﻿// Decompiled with JetBrains decompiler
// Type: WindowsFormsApp7.Form1
// Assembly: WindowsFormsApp7, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E908FC6C-F87D-440C-92BE-3E4D533491DF
// Assembly location: F:\Malware\Nikosoft Skidded Shit\WindowsFormsApp7.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace WindowsFormsApp7
{
  public class Form1 : Form
  {
    private IContainer components;
    private Button button1;
    private Label label1;

    public Form1() => this.InitializeComponent();

    private void Form1_Load(object sender, EventArgs e)
    {
    }

    private void button1_Click(object sender, EventArgs e)
    {
      int num = (int) MessageBox.Show("fuck off test app");
    }

    private void label1_Click(object sender, EventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form1));
      this.button1 = new Button();
      this.label1 = new Label();
      this.SuspendLayout();
      this.button1.Location = new Point(400, 79);
      this.button1.Name = "button1";
      this.button1.Size = new Size(366, 163);
      this.button1.TabIndex = 0;
      this.button1.Text = "HUAYJGJIsfedguuuuv";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new EventHandler(this.button1_Click);
      this.label1.AutoSize = true;
      this.label1.Location = new Point(147, 267);
      this.label1.Name = "label1";
      this.label1.Size = new Size(586, 16);
      this.label1.TabIndex = 1;
      this.label1.Text = "AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH";
      this.label1.Click += new EventHandler(this.label1_Click);
      this.AutoScaleDimensions = new SizeF(8f, 16f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(800, 450);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.button1);
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (Form1);
      this.Text = "kiki IS stupid";
      this.Load += new EventHandler(this.Form1_Load);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
