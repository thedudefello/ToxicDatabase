﻿// Decompiled with JetBrains decompiler
// Type: Test
// Assembly: Test, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7F2F113D-C490-4EB6-9F3B-805F9774A3D5
// Assembly location: F:\Malware\Nikosoft Skidded Shit\test.exe

using System;
using System.Runtime.InteropServices;
using System.Threading;

#nullable disable
public class Test
{
  public const uint DSTINVERT = 5570569;
  public const int SM_CXSCREEN = 0;
  public const int SM_CYSCREEN = 1;

  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool PatBlt(IntPtr hdc, int x, int y, int width, int height, uint rop);

  [DllImport("user32.dll")]
  public static extern IntPtr GetDC(IntPtr hWnd);

  [DllImport("user32.dll")]
  public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

  [DllImport("user32.dll")]
  public static extern int GetSystemMetrics(int nIndex);

  public static void Main(string[] args)
  {
    IntPtr dc = Test.GetDC(IntPtr.Zero);
    if (dc == IntPtr.Zero)
    {
      Console.WriteLine("Failed to get device context.");
    }
    else
    {
      int systemMetrics1 = Test.GetSystemMetrics(0);
      int systemMetrics2 = Test.GetSystemMetrics(1);
      Random random = new Random();
      for (int index = 0; index < 100; ++index)
      {
        int x = random.Next(0, systemMetrics1);
        int y = random.Next(0, systemMetrics2);
        int width = random.Next(50, 200);
        int height = random.Next(50, 200);
        Test.PatBlt(dc, x, y, width, height, 5570569U);
        Thread.Sleep(100);
      }
      Test.ReleaseDC(IntPtr.Zero, dc);
    }
  }
}
